# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.pagesizes import landscape
from reportlab.platypus import Image
from django.http import HttpResponse
from . import forms

def letter_create(request):
	if request.method=='POST':
		form=forms.LetterGenerator(request.POST,request.FILES)
		if form.is_valid():
			instance=form.save(commit=False)
			instance.save()
			first_name = form.cleaned_data.get('firstname')
			last_name = form.cleaned_data.get('lastname')
			email_id = form.cleaned_data.get('email')
			contact_number = form.cleaned_data.get('contact')

			pdf_file_name= last_name+' '+ first_name + '.pdf'
			user_name = first_name + ' ' + last_name
			c = canvas.Canvas(pdf_file_name, pagesize=landscape(letter))

			# heading
			c.setFont('Helvetica', 45, leading=None)
			c.drawString(160, 500, "Jivass Technologies")

			# User name
			c.setFont('Helvetica-Bold', 20, leading=None)
			c.drawString(80, 400, user_name)

			#is working in Jivass Technologies.
			c.setFont('Helvetica', 18, leading=None)
			c.drawString(230, 400, "is working in Jivass Technologies.")

			#Email-ID:
			c.setFont('Helvetica', 18, leading=None)
			c.drawString(80, 360, "Email-ID:")

			#Email ID
			c.setFont('Helvetica-Bold', 20, leading=None)
			c.drawString(165, 360, email_id)

			#Contact number:
			c.setFont('Helvetica', 18, leading=None)
			c.drawString(80, 320, "Contact number:")

			#Contact number
			c.setFont('Helvetica-Bold', 20, leading=None)
			c.drawString(220, 320, contact_number)

			# logo
			logo = 'assets/Jivass_technologies.png'
			c.drawImage(logo, 50, 500, width=None, height=None)

			c.showPage()
			c.save()

			#return redirect('http://127.0.0.1:8000/letter/generate')
			return render(request,'LetterGeneration/letter_create_success.html',{})

	else:
		form=forms.LetterGenerator()
	return render(request,'LetterGeneration/letter_create.html',{'form':form})
